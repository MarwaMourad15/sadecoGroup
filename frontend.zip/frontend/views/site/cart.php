<?php
/**
 * Created by PhpStorm.
 * User: marwa
 * Date: 31/08/16
 * Time: 06:08 م
 */
?>

<!--page Tittle-->
<div class="page-tittle">
    <div class="container">
        <div class="row">
            <h2>
                Your Cart Item
            </h2>
        </div>
    </div>
</div>
<!--Page Tittle-->

<!--Start Content-->
<div class="content">
    <!--Start Navbar-->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <!--Vission-->
                <div class="go-to-link sadeco-group">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="media">
                                <div class="media-left">
                                    <img class="media-object" src="img/media-1.jpg" alt="media1">
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading">Tittle</h4>
                                    hat a reader will be distracted by the readable content of a page when looking atm
                                    hat a reader will be distracted by the readable content of a page when looking at
                                </div>
                                <button type="button" class="btn btn-danger">Delete</button>
                            </div>
                            <div class="notes">
                                <h3>Note</h3>
                                <div class="row">
                                    <div class="col-sm-10 col-xs-12">
                                        <textarea></textarea>
                                    </div>
                                    <div class="col-sm-2 col-xs-12">
                                        <div class="arr">
                                            <i class="fa fa-chevron-up text-center click-plus" aria-hidden="true" onclick="count_val(1)"></i>
                                            <br>
                                            <input type="text" id="amount" onkeyup="count_val(0)" value="1">
                                            <br>
                                            <i class="fa fa-chevron-down text-center click-min" aria-hidden="true" onclick="count_val(-1)"></i>
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="go-to-link sadeco-group">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="media">
                                <div class="media-left">
                                    <img class="media-object" src="img/media-1.jpg" alt="media1">
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading">Tittle</h4>
                                    hat a reader will be distracted by the readable content of a page when looking atm
                                    hat a reader will be distracted by the readable content of a page when looking at
                                </div>
                                <button type="button" class="btn btn-danger">Delete</button>
                            </div>
                            <div class="notes">
                                <h3>Note</h3>
                                <div class="row">
                                    <div class="col-sm-10 col-xs-12">
                                        <textarea></textarea>
                                    </div>
                                    <div class="col-sm-2 col-xs-12">
                                        <div class="arr">
                                            <i class="fa fa-chevron-up text-center click-plus" aria-hidden="true" onclick="count_val2(1)"></i>
                                            <br>
                                            <input type="text" id="amount2" onkeyup="count_val2(0)" value="1">
                                            <br>
                                            <i class="fa fa-chevron-down text-center click-min" aria-hidden="true" onclick="count_val2(-1)"></i>
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Vission-->
            </div>
        </div>
    </div>
    <!--End navbar-->
</div>
<!--End Content-->
