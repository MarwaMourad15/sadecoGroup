<div class="menu col-md-2 col-xs-12">
    <ul class="list-unstyled">
        <li class="color">
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            <a href="<?php echo Yii::$app->homeUrl;?>profile/index">Profile</a>
        </li>
        <li>
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            <a href="<?php echo Yii::$app->homeUrl;?>profile/certificate">Certificate</a>
        </li>
        <li>
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            <a href="<?php echo Yii::$app->homeUrl;?>profile/openrfq">OpenRFQ</a>
        </li>
        <li>
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            <a href="<?php echo Yii::$app->homeUrl;?>profile/rfq">Rfq</a>
        </li>
        <li>
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            <a href="<?php echo Yii::$app->homeUrl;?>profile/alerts">Alerts</a>
        </li>
    </ul>
</div>