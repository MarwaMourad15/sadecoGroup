<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = 'open RFQ';
?>

<!--page Tittle-->
<div class="page-tittle">
    <div class="container">
        <div class="row">
            <h2>
                openRFQ
            </h2>
        </div>
    </div>
</div>
<!--Page Tittle-->
<!--Start Content-->
<div class="content">
    <!--Start Navbar-->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <!--Company History-->
                <div class="services sadeco-group">
                    <?php if(empty($openRFQ)){ ?>
                        <h1>No Results</h1>
                    <?php } ?>
                </div>

                </div>
                <!--Company History-->
            </div>
        </div>
    </div>

</div>
<!--End Content-->
