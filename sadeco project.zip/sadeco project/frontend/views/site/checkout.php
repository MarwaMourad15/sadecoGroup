<?php
/**
 * Created by PhpStorm.
 * User: marwa
 * Date: 31/08/16
 * Time: 06:08 م
 */
use yii\widgets\ActiveForm;

$items = array();
$item1 = array();
$item1['part_no']= '1885';
$item1['quantity'] = 2;
$item1['certificate_of_conformity'] = 0;
$item1['installion_required'] = 0;
$item1['on_site_service'] = 0;
$item1['note'] = 'test';
$item1['enable_recurring'] = true;
$item1['frequency_in_months'] = 2;
$item2 = array();
$item2['part_no']= '1886';
$item2['quantity'] = 2;
$item2['certificate_of_conformity'] = 0;
$item2['installion_required'] = 0;
$item2['on_site_service'] = 0;
$item2['note'] = 'test';
$item2['enable_recurring'] = true;
$item2['frequency_in_months'] = 2;

$items[0] = $item1;
$items[1] = $item2;

$items_ser = base64_encode(json_encode($items));

echo '<pre>';
print_r($items);
echo '</pre>';

$this->title = 'Chechout';
?>

<!--page Tittle-->
<div class="page-tittle">
    <div class="container">
        <div class="row">
            <h2>
                Checkout
            </h2>
        </div>
    </div>
</div>
<!--Page Tittle-->

<!--Start Content-->
<div class="content">
    <!--Start Navbar-->
    <div class="container">
        <div class="row">
            <?php $form = ActiveForm::begin([
                //'action' => ['index'],
                'method' => 'post',
                'options' => ['class' => 'con'],
            ]); ?>
            <div class="col-xs-12">
                <h1>Accout Information</h1>
                Contact Email : <input type="email" name="contact_email"><br><br>
                Delivery Method :
                <select name="deliver_method">
                <?php foreach($delivery_methods as $key => $value){?>
                    <option value="<?php echo $value['delivery_method_id']; ?>"><?php echo $value['delivery_method']; ?></option>
                <?php } ?>
                </select><br>
                Delivery Date : <input name="delivery_date" type="date"><br><br>
                Billing Country :
                <select name="billing_country">
                    <?php foreach($billing_countries as $key => $value){?>
                        <option value="<?php echo $value['country_id']; ?>"><?php echo $value['country']; ?></option>
                    <?php } ?>
                </select><br><br>
                Billing City :
                <input type="text" name="billing_city"><br><br>
                Billing Address :
                <input type="text" name="billing_address"><br><br>
                Shipping Country :
                <select name="shipping_country">
                    <?php foreach($shipping_countries as $key => $value){?>
                        <option value="<?php echo $value['country_id']; ?>"><?php echo $value['country']; ?></option>
                    <?php } ?>
                </select><br><br>
                Shipping City :
                <input type="text" name="shipping_city"><br><br>
                Shipping Address :
                <input type="text" name="shipping_address"><br><br>
                <input type="hidden" value="<?php echo $items_ser?>" name="items" >
                <button type="submit" name="submit" class="btn btn-default">Submit</button>

            </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
    <!--End navbar-->
</div>
<!--End Content-->
